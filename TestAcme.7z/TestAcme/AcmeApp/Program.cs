using AcmeApp.Data;
using AcmeApp.Models;
using AcmeApp.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting.Internal;
using System.Configuration;
using System.Globalization;

var builder = WebApplication.CreateBuilder(args);

// Get Configuration
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
int minimumLength = builder.Configuration.GetValue<int>("PasswordConfiguration:MinimumLength");
int specialCharacters = builder.Configuration.GetValue<int>("PasswordConfiguration:SpecialCharachters");

// Add services to the container.
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(connectionString));

builder.Services.AddDatabaseDeveloperPageExceptionFilter();

builder.Services.AddDefaultIdentity<AcmeAppUser>(options => options.SignIn.RequireConfirmedAccount = false)
    .AddEntityFrameworkStores<ApplicationDbContext>();

builder.Services.AddRazorPages();

builder.Services.Configure<IdentityOptions>(options =>
{
    // Default Password settings.
    options.Password.RequireDigit = true;
    options.Password.RequireLowercase = true;
    options.Password.RequireNonAlphanumeric = true;
    options.Password.RequireUppercase = true;
    options.Password.RequiredLength = minimumLength;
    options.Password.RequiredUniqueChars = 1;
});


if (builder.Environment.IsDevelopment())
{
    builder.Services.AddControllersWithViews(options => {
        options.Filters.Add(new AutoValidateAntiforgeryTokenAttribute());
    }).AddRazorRuntimeCompilation();
}
else
{
    builder.Services.AddControllersWithViews(options => {
        options.Filters.Add(new AutoValidateAntiforgeryTokenAttribute());
    });
}
// Add application services.
builder.Services.AddTransient<IEmailSender, EmailService>();
builder.Services.AddTransient<IPasswordValidator<AcmeAppUser>, CustomPasswordPolicy>();
builder.Services.AddTransient<IPasswordGenerator, PasswordGenerator>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseMigrationsEndPoint();
}
else
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
var supportedCultures = new[]
{
 //new CultureInfo("en-US"),
 new CultureInfo("fr"),
};
app.UseRequestLocalization(new RequestLocalizationOptions
{
    DefaultRequestCulture = new RequestCulture("fr"),
    // Formatting numbers, dates, etc.
    SupportedCultures = supportedCultures,
    // UI strings that we have localized.
    SupportedUICultures = supportedCultures
});

app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");
app.MapRazorPages();

app.Run();
