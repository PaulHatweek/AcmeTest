﻿using System.Text;

namespace AcmeApp.Services
{
    public class PasswordGenerator : IPasswordGenerator
    {
        public string GeneratePassword(int minmumlength, int minimumSpecialChar)
        {
            int length = minmumlength - minimumSpecialChar;
            StringBuilder passBuilder = new(minmumlength);
            string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            var random = new Random();
            passBuilder.Append(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
            
            passBuilder.Append(Enumerable.Repeat(IPasswordGenerator.SpecialsChars, minimumSpecialChar)
              .Select(s => s[random.Next(s.Length)]).ToArray());
            return passBuilder.ToString();
        }
    }
}
