﻿
namespace AcmeApp.Services;

public class EmailService : IEmailSender
{
    public async Task SendEmailAsync(string email, string subject, string message)
    {
        // Plug in your email service here to send an email.
        // we could use SMTP client to send the email
        // Or as Microsoft recommended we use MailKit
        // in all the caes we need to the SMTP server configuration
        //     SMTP server,  SMTP Credentials, sender email and name
        // Compose the message, we could have a template and we populate
        // we set the the sender the recipient
        // send the message
        await Task.FromResult(0);
    }
}
