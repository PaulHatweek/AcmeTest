﻿using AcmeApp.Models;
using Microsoft.AspNetCore.Identity;

namespace AcmeApp.Services
{
    public class UserRegistreValidator
    {
        //UserManager<AcmeAppUser> userManager,
        //        SignInManager<AcmeAppUser> SignInManager,
    }
}
