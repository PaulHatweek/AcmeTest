﻿using AcmeApp.Models;
using Microsoft.AspNetCore.Identity;
using System.Text.RegularExpressions;

namespace AcmeApp.Services
{
    public class CustomPasswordPolicy : PasswordValidator<AcmeAppUser>
    {
        protected int MinimumLength { get; }

        protected int SpecialCharacters { get; }
        public CustomPasswordPolicy(IConfiguration configuration)
        {
            MinimumLength = configuration.GetValue<int>("PasswordConfiguration:MinimumLength");
            SpecialCharacters = configuration.GetValue<int>("PasswordConfiguration:SpecialCharachters");
        }

        public override async Task<IdentityResult> ValidateAsync(UserManager<AcmeAppUser> manager, AcmeAppUser user, string password)
        {
            IdentityResult result = await base.ValidateAsync(manager, user, password);
            List<IdentityError> errors = result.Succeeded ? new List<IdentityError>() : result.Errors.ToList();

            if (Regex.Matches(password, $"[{IPasswordGenerator.SpecialsChars}]").Count < SpecialCharacters)
            {
                errors.Add(new IdentityError
                {
                    Description = $"le mot de pass doit contenir au moins {SpecialCharacters} caractères spéciaux"
                });
            }
            return errors.Count == 0 ? IdentityResult.Success : IdentityResult.Failed(errors.ToArray());
        }
    }
}
