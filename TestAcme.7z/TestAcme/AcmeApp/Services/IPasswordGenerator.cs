﻿namespace AcmeApp.Services
{
    public interface IPasswordGenerator
    {
        static string SpecialsChars = "~!@#$%^&*()_+{}:<>?";
        string GeneratePassword(int mimiumLength, int minimumSpecialChar);
    }
}
