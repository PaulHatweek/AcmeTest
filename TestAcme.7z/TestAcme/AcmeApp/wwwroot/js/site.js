﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
$.validator.addMethod(
    "email",
    function (value, element) {
        return this.optional(element) || /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/.test(value);
    },
    "This e-mail is not valid"
);

$.ajaxSetup({
    cache: false
});

function SetNavigationActive(cssclass) {
    var selector = '#mainMenu li a.' + cssclass;
    $('#mainMenu li').removeClass('active');
    $(selector).addClass('active');
}