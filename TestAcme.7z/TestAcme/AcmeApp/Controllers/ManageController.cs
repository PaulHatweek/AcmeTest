﻿using AcmeApp.Models;
using AcmeApp.Services;
using AcmeApp.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using NuGet.Common;
using System.Security.Policy;

namespace AcmeApp.Controllers
{
    [Authorize]
    public class ManageController : BaseController
    {
        public ManageController(UserManager<AcmeAppUser> userManager,
                SignInManager<AcmeAppUser> signInManager,
                IEmailSender emailSender,
                ILoggerFactory loggerFactory) : base(userManager, signInManager, emailSender, loggerFactory)
        {

        }

        public async Task<IActionResult> Index()
        {
            var profileVieModel = new ProfileViewModel();
            var user = await GetCurrentUserAsync();
            if(user != null)
            {
                profileVieModel.DisplayName = user.DisplayName;
                profileVieModel.Email = user.Email;
                profileVieModel.UserName = user.UserName;
            }
            
            return View(profileVieModel);
        }

        //
        // POST: /Manage/UpdateProfile
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateProfile(ProfileViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(nameof(Index), model);
            }

            var user = await GetCurrentUserAsync();
            if (user != null)
            {
                user.DisplayName = model.DisplayName;
                var result = await _userManager.UpdateAsync(user);
                if (!result.Succeeded)
                {
                    AddErrors(result);
                    return View(nameof(Index), model);
                }
                if (!string.IsNullOrEmpty(model.Password))
                {
                    var token = await _userManager.GeneratePasswordResetTokenAsync(user);
                    result = await _userManager.ResetPasswordAsync(user, token, model.Password);
                }
                
                if (!result.Succeeded)
                {
                    AddErrors(result);
                    return View(nameof(Index), model);
                }

                return RedirectToAction("Index", "Home");
            }
            return View(nameof(Index), model);
        }

 

    }
}
