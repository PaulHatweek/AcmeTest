﻿using AcmeApp.Models;
using AcmeApp.ViewModels;
using AcmeApp.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

namespace AcmeApp.Controllers
{
    [Authorize]
    public class AccountController : BaseController
    {
        private readonly IPasswordGenerator _passwordGenerator;
        private int _minimumLength;

        private int _specialCharacters;

        public AccountController(
                UserManager<AcmeAppUser> userManager,
                SignInManager<AcmeAppUser> signInManager,
                IConfiguration configuration,
                IEmailSender emailSender,
                IPasswordGenerator passwordGenerator,
                ILoggerFactory loggerFactory) : base(userManager, signInManager, emailSender, loggerFactory)
        {
            _passwordGenerator = passwordGenerator;
            _minimumLength = configuration.GetValue<int>("PasswordConfiguration:MinimumLength");
            _specialCharacters = configuration.GetValue<int>("PasswordConfiguration:SpecialCharachters");
        }

        //
        // GET: /Account/Login
        [HttpGet]
        [AllowAnonymous]
        public IActionResult Login(string? returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            var model = new LoginViewModel();
            return View(model);
        }

        //
        // POST: /Account/Login
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model, string? returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            if (ModelState.IsValid)
            {
                AcmeAppUser user;
                if (model.UserName.Contains("@"))
                    user = await _userManager.FindByEmailAsync(model.UserName);
                else
                    user = await _userManager.FindByNameAsync(model.UserName);

                if (user != null)
                {
                    var result = await _signInManager.PasswordSignInAsync(user.UserName, model.Password, model.RememberMe, lockoutOnFailure: false);
                    if (result.Succeeded)
                    {
                        _logger.LogInformation(1, "User logged in.");
                        return RedirectToLocal(returnUrl);
                    }
                    if (result.IsLockedOut)
                    {
                        _logger.LogWarning(2, "User account locked out.");
                        ModelState.AddModelError(string.Empty, "Compte utilisateur verrouillé.");
                        return View(model);
                    }
                    else
                    {
                        ModelState.AddModelError(string.Empty, "Tentative de connexion invalide.");
                        return View(model);
                    }
                }
                ModelState.AddModelError(string.Empty, "Tentative de connexion invalide.");
            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }

        //
        // GET: /Account/Register
        [HttpGet]
        [AllowAnonymous]
        public IActionResult Register(string? returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            var model = new RegisterViewModel();
            return View(model);
        }

        //
        // POST: /Account/Register
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel model, string? returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            if (ModelState.IsValid)
            {
                var user = new AcmeAppUser { DisplayName = model.DisplayName, UserName = model.UserName, Email = model.Email };
                var password = _passwordGenerator.GeneratePassword(_minimumLength, _specialCharacters);
                var result = await _userManager.CreateAsync(user, password);
                List<IdentityError> errors = result.Succeeded ? new List<IdentityError>() : result.Errors.ToList();
                
                if (result.Succeeded)
                {
                    await _emailSender.SendEmailAsync(model.Email, "merci pour notre Inscription", 
                        $"Merci pour votre Inscription chez ACME voici votre mot de passe: {password}" );
                    
                    _logger.LogInformation(3, "User created a new account with password.");
                    return RedirectToAction(nameof(Login));
                }
                AddErrors(result);
            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }

        //
        // POST: /Account/LogOff
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> LogOff()
        {
            await _signInManager.SignOutAsync();
            _logger.LogInformation(4, "User logged out.");
            return RedirectToAction(nameof(HomeController.Index), "Home");
        }

    }
}
