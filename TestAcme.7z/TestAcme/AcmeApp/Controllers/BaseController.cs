﻿using AcmeApp.Models;
using AcmeApp.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace AcmeApp.Controllers
{
    public class BaseController : Controller
    {
        protected readonly UserManager<AcmeAppUser> _userManager;
        protected readonly SignInManager<AcmeAppUser> _signInManager;
        protected readonly IEmailSender _emailSender;
        protected readonly ILogger _logger;

        public BaseController(
                UserManager<AcmeAppUser> userManager,
                SignInManager<AcmeAppUser> signInManager,
                IEmailSender emailSender,
                ILoggerFactory loggerFactory)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _emailSender = emailSender;
            _logger = loggerFactory.CreateLogger<ManageController>();
        }

        protected void AddErrors(IdentityResult result)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError(string.Empty, error.Description);
            }
        }

        protected Task<AcmeAppUser> GetCurrentUserAsync()
        {
            return _userManager.GetUserAsync(HttpContext.User);
        }

        protected IActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            else
            {
                return RedirectToAction(nameof(HomeController.Index), "Home");
            }
        }

    }
}
